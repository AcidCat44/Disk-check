@echo off
title Disk Check
color 0B

echo.
color 0C
echo This program needs to be ran as an administrator!
color 0C
echo.
pause

cls

echo.
color 0C
echo WARNING: This uses chkdsk which can take a long time and also repairs files!
color 0C
echo.
pause

cls
color 0B

set /p drive=Enter drive letter to check:

echo.
echo Checking drive %drive%
echo.

chkdsk %drive%: /f

echo.
pause